﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QLThucAn.Models;
using PagedList;
using PagedList.Mvc;

namespace QLThucAn.Controllers
{
    public class ThucAnController : Controller
    {
        QLthucanEntities3 data = new QLthucanEntities3();
        // GET: ThucAn
        public ActionResult Index(int? page)
        {
            int iSize = 6;
            int iPageNum = (page ?? 1);
            return View(data.THUCANs.OrderBy(n => n.MaThucAn).ToPagedList(iPageNum, iSize));
        }

        public ActionResult ChiTietThucAn(int id)
        {
            var thucan = from s in data.THUCANs where s.MaThucAn == id select s;
            return View(thucan.Single());
        }

        public ActionResult ThucAnTheoLoai(int iMaLoai, int? page)
        {
            ViewBag.MaLoai= iMaLoai;
            int iSize = 6;
            int iPageNum = (page ?? 1);
            var sach = from s in data.THUCANs where s.MaLoai == iMaLoai select s;
            return View(sach.OrderBy(n => n.MaLoai).ToPagedList(iPageNum, iSize));
        }
       
        public ActionResult Loai()
        {
            return PartialView(data.LOAIs.ToList());
        }
        public ActionResult LoginLogout()
        {
            return PartialView("LoginLogout");
        }
    }
}