﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QLThucAn.Models
{
    public class GioHang
    {
        QLthucanEntities3 data = new QLthucanEntities3();
        public int iMaThucAn { get; set; }
        public string sTenThucAn { get; set; }
        public string sAnhBia { get; set; }
        public double dDonGia { get; set; }
        public int iSoLuong { get; set; }
        public double dThanhTien
        {
            get { return iSoLuong * dDonGia; }
        }
        public GioHang(int ms)
        {
            iMaThucAn = ms;
            THUCAN s = data.THUCANs.Single(n => n.MaThucAn == iMaThucAn);
            sTenThucAn = s.TenThucAn;
            sAnhBia = s.HinhMinhHoa;
            dDonGia = double.Parse(s.DonGia.ToString());
            iSoLuong = 1;
        }
    }
}