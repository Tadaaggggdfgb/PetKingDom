﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QLThucAn.Models;
using PagedList;
using PagedList.Mvc;
using System.IO;

namespace QLThucAn.Areas.Admin.Controllers
{
    public class ThucAnController : Controller
    {
        QLthucanEntities3 data = new QLthucanEntities3();
        // GET: Admin/ThucAn
        public ActionResult Index(int ? page)
        {
            if (Session["Admin"] == null || Session["Admin"].ToString() == "")
            {
                return Redirect("~/Admin/Home/Login");
            }

            int iPageNum = (page ?? 1);
            int iPageSize = 6;
            return View(data.THUCANs.ToList().OrderBy(n => n.MaThucAn).ToPagedList(iPageNum, iPageSize));
        }
        [HttpGet]
        public ActionResult Create()
        {
            if (Session["Admin"] == null || Session["Admin"].ToString() == "")
            {
                return Redirect("~/Admin/Home/Login");
            }
            ViewBag.MaLoai = new SelectList(data.LOAIs.ToList().OrderBy(n => n.TenLoai), "MaLoai", "TenLoai");
            ViewBag.MaNSX = new SelectList(data.NHASANXUATs.ToList().OrderBy(n => n.TenNSX), "MaNSX", "TenNSX");
            return View();
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Create(THUCAN sach, FormCollection f, HttpPostedFileBase fFileUpload)
        {
            ViewBag.MaLoai = new SelectList(data.LOAIs.ToList().OrderBy(n => n.TenLoai), "MaLoai", "TenLoai");
            ViewBag.MaNSX = new SelectList(data.NHASANXUATs.ToList().OrderBy(n => n.TenNSX), "MaNSX", "TenNSX");
            if (fFileUpload == null)
            {
                ViewBag.ThongBao = "Hãy chọn ảnh bìa.";
                ViewBag.TenSach = f["sTenSach"];
                ViewBag.MoTa = f["sMoTa"];
                ViewBag.SoLuong = int.Parse(f["iSoLuong"]);
                ViewBag.GiaBan = decimal.Parse(f["mGiaBan"]);
                ViewBag.MaLoai = new SelectList(data.LOAIs.ToList().OrderBy(n => n.TenLoai), "MaLoai", "TenLoai", int.Parse(f["MaLoai"]));
                ViewBag.MaNSX = new SelectList(data.NHASANXUATs.ToList().OrderBy(n => n.TenNSX), "MaNSX", "TenNSX", int.Parse(f["MaNSX"]));
                return View();
            }
            else
            {
                if (ModelState.IsValid)
                {
                    var sFileName = Path.GetFileName(fFileUpload.FileName);
                    var path = Path.Combine(Server.MapPath("~/Content/images"), sFileName);
                    if (!System.IO.File.Exists(path))
                    {
                        fFileUpload.SaveAs(path);
                    }
                    sach.TenThucAn = f["sTenSach"];
                    sach.MoTa = f["sMoTa"].Replace("<p>", "").Replace("</p>", "\n");
                    sach.HinhMinhHoa = sFileName;
                    sach.NgayCapNhat = Convert.ToDateTime(f["dNgayCapNhat"]);
                    sach.SoLuongBan = int.Parse(f["iSoLuong"]);
                    sach.DonGia = decimal.Parse(f["mGiaBan"]);
                    sach.MaLoai = int.Parse(f["MaLoai"]);
                    sach.MaNSX = int.Parse(f["MaNSX"]);
                    data.THUCANs.Add(sach);
                    data.SaveChanges();
                    return RedirectToAction("Index");
                }
                return View();
            }
        }
        public ActionResult Details(int id)
        {
            var sach = data.THUCANs.SingleOrDefault(n => n.MaThucAn == id);
            if (sach == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            return View(sach);
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {
            var sach = data.THUCANs.SingleOrDefault(n => n.MaThucAn == id);
            if (sach == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            return View(sach);
        }
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirm(int id, FormCollection f)
        {
            var sach = data.THUCANs.SingleOrDefault(n => n.MaThucAn == id);
            if (sach == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            var ctdh = data.CTDATHANGs.Where(ct => ct.MaThucAn == id);
            if (ctdh.Count() > 0)
            {
                ViewBag.ThongBao = "Thức ăn này đang có trong bảng Chi tiết đặt hàng <br>" + " Nếu muốn xóa thì phải xóa hết mã sách này trong bảng Chi tiết đặt hàng";

                return View(sach);
            }
            
            data.THUCANs.Remove(sach);
            data.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var sach = data.THUCANs.SingleOrDefault(n => n.MaThucAn == id);
            if (sach == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            ViewBag.MaLoai = new SelectList(data.LOAIs.ToList().OrderBy(n => n.TenLoai), "MaLoai", "TenLoai");
            ViewBag.MaNSX = new SelectList(data.NHASANXUATs.ToList().OrderBy(n => n.TenNSX), "MaNSX", "TenNSX");
            return View(sach);
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Edit(int id, FormCollection f, HttpPostedFile fFileUpload)
        {
            var sach = data.THUCANs.SingleOrDefault(n => n.MaThucAn == id);
            ViewBag.MaLoai = new SelectList(data.LOAIs.ToList().OrderBy(n => n.TenLoai), "MaLoai", "TenLoai", sach.MaLoai);
            ViewBag.MaNSX = new SelectList(data.NHASANXUATs.ToList().OrderBy(n => n.TenNSX), "MaNSX", "TenNSX", sach.MaNSX);
            if (ModelState.IsValid)
            {
                if (fFileUpload != null)
                {
                    var sFileName = Path.GetFileName(fFileUpload.FileName);
                    var path = Path.Combine(Server.MapPath("~/Content/images"), sFileName);
                    if (!System.IO.File.Exists(path))
                    {
                        fFileUpload.SaveAs(path);
                    }
                    sach.HinhMinhHoa = sFileName;
                }
                sach.MaThucAn = int.Parse(f["iMaSach"]);
                sach.TenThucAn = f["sTenSach"];
                sach.MoTa = f["sMoTa"].Replace("<p>", "").Replace("</p>", "\n");
                sach.NgayCapNhat = Convert.ToDateTime(f["dNgayCapNhat"]);
                sach.DonGia = decimal.Parse(f["mGiaBan"]);
                sach.SoLuongBan = int.Parse(f["iSoLuong"]);
                sach.MaLoai = int.Parse(f["MaLoai"]);
                sach.MaNSX= int.Parse(f["MaNSX"]);
                data.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(sach);
        }
    }
}