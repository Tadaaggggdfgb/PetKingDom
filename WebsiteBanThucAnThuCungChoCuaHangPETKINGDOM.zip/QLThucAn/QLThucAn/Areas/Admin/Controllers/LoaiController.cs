﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QLThucAn.Models;
using PagedList;
using PagedList.Mvc;
using System.IO;

namespace QLThucAn.Areas.Admin.Controllers
{
    public class LoaiController : Controller
    {
        QLthucanEntities3 data = new QLthucanEntities3();
        public ActionResult Index(int? page)
        {
            if (Session["Admin"] == null || Session["Admin"].ToString() == "")
            {
                return Redirect("~/Admin/Home/Login");
            }
            int iPageNum = (page ?? 1);
            int iPageSize = 7;
            return View(data.LOAIs.ToList().OrderBy(n => n.MaLoai).ToPagedList(iPageNum, iPageSize));
        }
        [HttpGet]
        public ActionResult Create()
        {
            if (Session["Admin"] == null || Session["Admin"].ToString() == "")
            {
                return Redirect("~/Admin/Home/Login");
            }
            return View();
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Create(LOAI loai, FormCollection f)
        {
            if (loai == null)
            {
                ViewBag.TenLoai = f["sTenLoai"];
                return View();
            }
            else
            {
                loai.TenLoai = f["sTenLoai"];
                data.LOAIs.Add(loai);
                data.SaveChanges();
                return RedirectToAction("Index");
            }
        }
        public ActionResult Details(int id)
        {
            var loai = data.LOAIs.SingleOrDefault(n => n.MaLoai == id);
            if (loai == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            return View(loai);
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {
            var loai = data.LOAIs.SingleOrDefault(n => n.MaLoai == id);
            if (loai == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            return View(loai);
        }
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirm(int id, FormCollection f)
        {
            var loai = data.LOAIs.SingleOrDefault(n => n.MaLoai == id);
            if (loai == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            data.LOAIs.Remove(loai);
            data.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var loai = data.LOAIs.SingleOrDefault(n => n.MaLoai == id);
            if (loai == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            return View(loai);
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Edit(int id, FormCollection f)
        {
            var loai = data.LOAIs.SingleOrDefault(n => n.MaLoai == id);
            if (loai == null)
            {
                loai.MaLoai = int.Parse(f["iMaLoai"]);
                return View(loai);
            }
            else
            {
                loai.TenLoai = f["sTenLoai"];
                data.SaveChanges();
                return RedirectToAction("Index");
            }
        }
    }
}