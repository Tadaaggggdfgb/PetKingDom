﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList.Mvc;
using System.IO;
using PagedList;
using QLThucAn.Models;

namespace QLThucAn.Areas.Admin.Controllers
{
    public class KhachHangController : Controller
    {
        // GET: Admin/KhachHang
        QLthucanEntities3 data = new QLthucanEntities3();
        public ActionResult Index(int? page)
        {
            if (Session["Admin"] == null || Session["Admin"].ToString() == "")
            {
                return Redirect("~/Admin/Home/Login");
            }
            int iPageNum = (page ?? 1);
            int iPageSize = 7;
            return View(data.KHACHHANGs.ToList().OrderBy(n => n.MaKH).ToPagedList(iPageNum, iPageSize));
        }
        [HttpGet]
        public ActionResult Create()
        {
            if (Session["Admin"] == null || Session["Admin"].ToString() == "")
            {
                return Redirect("~/Admin/Home/Login");
            }
            return View();
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Create(KHACHHANG kh, FormCollection f)
        {
            if (kh == null)
            {
                ViewBag.HoTenKH = f["sHoTenKH"];
                ViewBag.DiaChiKH = f["sDiaChiKH"];
                ViewBag.DienThoaiKH = f["sDienThoaiKH"];
                ViewBag.TenDN = f["sTenDN"];
                ViewBag.MatKhau = f["sMatKhau"];
                ViewBag.NgaySinh = string.Format("{0:MM/dd/yyyy}", f["sNgaySinh"]);
                ViewBag.GioiTinh = f["sGioiTinh"];
                ViewBag.Email = f["sEmail"];
                return View();
            }
            else
            {
                kh.HoTenKH = f["sHoTenKH"];
                kh.DiaChiKH = f["sDiaChiKH"];
                kh.DienThoaiKH = f["sDienThoaiKH"];
                kh.TenDN = f["sTenDN"];
                kh.MatKhau = f["sMatKhau"];
                kh.NgaySinh = DateTime.Parse(f["sNgaySinh"]);
                kh.GioiTinh = bool.Parse(f["sGioiTinh"]);
                kh.Email = f["sEmail"];
                data.KHACHHANGs.Add(kh);
                data.SaveChanges();
                return RedirectToAction("Index");
            }
        }
        public ActionResult Details(int id)
        {
            var kh = data.KHACHHANGs.SingleOrDefault(n => n.MaKH == id);
            if (kh == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            return View(kh);
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {
            var kh = data.KHACHHANGs.SingleOrDefault(n => n.MaKH == id);
            if (kh == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            return View(kh);
        }
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirm(int id, FormCollection f)
        {
            var kh = data.KHACHHANGs.SingleOrDefault(n => n.MaKH == id);
            if (kh == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            data.KHACHHANGs.Remove(kh);
            data.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var kh = data.KHACHHANGs.SingleOrDefault(n => n.MaKH == id);
            if (kh == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            return View(kh);
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Edit(int id, FormCollection f)
        {
            var kh = data.KHACHHANGs.SingleOrDefault(n => n.MaKH == id);
            if (kh == null)
            {
                kh.HoTenKH = f["sHoTenKH"];
                kh.DiaChiKH = f["sDiaChiKH"];
                kh.DienThoaiKH = f["sDienThoaiKH"];
                kh.TenDN = f["sTenDN"];
                kh.MatKhau = f["sMatKhau"];
                kh.NgaySinh = DateTime.Parse(f["sNgaySinh"]);
                kh.GioiTinh = bool.Parse(f["sGioiTinh"]);
                kh.Email = f["sEmail"];
                return View(kh);
            }
            else
            {
                kh.HoTenKH = f["sHoTenKH"];
                kh.DiaChiKH = f["sDiaChiKH"];
                kh.DienThoaiKH = f["sDienThoaiKH"];
                kh.TenDN = f["sTenDN"];
                kh.MatKhau = f["sMatKhau"];
                kh.NgaySinh = DateTime.Parse(f["sNgaySinh"]);
                kh.GioiTinh = bool.Parse(f["sGioiTinh"]);
                kh.Email = f["sEmail"];
                data.SaveChanges();
                return RedirectToAction("Index");
            }
        }
    }
}